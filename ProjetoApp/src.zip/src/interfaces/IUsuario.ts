export interface IUsuario {
  id: number;
  nome: string;
  cpf: string;
  img: string;
}
