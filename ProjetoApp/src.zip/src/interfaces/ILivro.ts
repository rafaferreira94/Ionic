export interface ILivro {
  id: number;
  titulo: string;
  ano: number;
  img: string;
  destaque: boolean;

}
