export interface ILivroAutor {
  livroId: number;
  autorId: number;
}
