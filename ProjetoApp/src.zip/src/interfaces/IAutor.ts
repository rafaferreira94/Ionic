export interface IAutor {
  id: number;
  nome: string;
  sobrenome: string;
  img: string;
}
